camera1394stereo
================

ROS package containing a driver for Firewire stereo cameras. See http://www.ros.org/wiki/camera1394stereo for more information.
