microstrain_3dm_gx3_45
======================

Driver implementing MIP protocol communication. Please see its documentation on: http://ros.org/wiki/microstrain_3dm_gx3_45.
